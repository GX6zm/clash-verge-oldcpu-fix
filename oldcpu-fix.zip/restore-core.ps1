﻿#requires -Version 5.1
<#
.SYNOPSIS
    把 Clash Verge 内核还原成安装包自带的原版（撤销 fix-core.ps1 的修改）。

.DESCRIPTION
    fix-core.ps1 替换内核时会把原文件备份成 verge-mihomo.exe.orig-broken。
    本脚本把这个备份还原回去，适合「换了内核反而不能用，想退回出厂状态」的场景。

.PARAMETER ClashVergeDir
    Clash Verge 安装目录，默认 C:\Program Files\Clash Verge

.EXAMPLE
    .\restore-core.ps1
#>
[CmdletBinding()]
param(
    [string]$ClashVergeDir = 'C:\Program Files\Clash Verge'
)

$ErrorActionPreference = 'Stop'

$WorkDir = Join-Path $env:ProgramData 'ClashVergeOldCpuFix'
$LogFile = Join-Path $WorkDir 'restore.log'
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null

function Write-Step {
    param([string]$Message)
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Host $Message
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    Write-Host '需要管理员权限，正在请求提权（请点「是」）...'
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($ClashVergeDir -ne 'C:\Program Files\Clash Verge') { $argList += @('-ClashVergeDir', "`"$ClashVergeDir`"") }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs
    return
}

Write-Step '================ 开始还原 Clash Verge 内核 ================'

$exe = Join-Path $ClashVergeDir 'clash-verge.exe'
$dst = Join-Path $ClashVergeDir 'verge-mihomo.exe'
$bak = Join-Path $ClashVergeDir 'verge-mihomo.exe.orig-broken'

try {
    if (-not (Test-Path $bak)) { throw "找不到备份文件：$bak（说明没有执行过 fix-core.ps1）" }

    if (Get-Process -Name 'clash-verge' -ErrorAction SilentlyContinue) {
        Write-Step '关闭 Clash Verge ...'
        Get-Process -Name 'clash-verge' -ErrorAction SilentlyContinue | Stop-Process -Force
        Start-Sleep -Seconds 3
    }
    Get-Process -Name 'verge-mihomo' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 1

    Copy-Item $bak $dst -Force
    Write-Step "已还原原内核：$dst"

    if (Test-Path $exe) {
        Write-Step '启动 Clash Verge ...'
        Start-Process $exe
    }

    Write-Step '================ 还原完成 ================'
    Write-Step '注意：原内核在老 CPU / 虚拟机上本来就会崩溃，还原只用于回到出厂状态。'
    exit 0
}
catch {
    Write-Step "失败：$($_.Exception.Message)"
    exit 1
}

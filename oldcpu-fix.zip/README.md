# Clash Verge 老 CPU / 虚拟机 内核修复包

> **装好 Clash Verge + 这个文件夹 = 一个能用的代理。**
> 不需要联网下载，内核已经放在文件夹里了。

适用于：老笔记本、QEMU/KVM 虚拟机、深信服 / 华为云桌面等 VDI 环境。
典型症状是 **Clash Verge 界面能打开，但内核起不来、代理用不了**。

## 文件夹里有什么

| 文件 | 作用 |
| --- | --- |
| `mihomo-windows-amd64-compatible.exe` | 内核本体（mihomo v1.19.34，老 CPU 兼容构建），离线自带 |
| `fix.bat` | **双击这个**，一键安装兼容内核 |
| `fix-core.ps1` | 实际干活的脚本：备份 → 替换 → 校验 → 启动 → 体检 |
| `restore.bat` / `restore-core.ps1` | 想退回原版内核时双击 `restore.bat` |
| `README.md` | 就是本文件 |

不含 Clash Verge 安装包本身，需要先自己装好。

## 三步搞定

### 第 1 步：装 Clash Verge

官网下载安装即可，装哪个版本都行（2.5.x 都验证过）。
装完**先打开一次**，让它生成配置目录，然后关掉。

### 第 2 步：双击 `fix.bat`

- 弹出 UAC 时点「是」（替换 `Program Files` 里的文件必须有管理员权限）
- 脚本会自动：关掉 Clash Verge → 备份原内核 → 换上兼容内核 → 实际跑一次校验 → 重新启动 Clash Verge → 把系统代理打开
- 最后会打印一段**体检结果**，理想情况是三行全部 `[完成]`：

```
---------------- 体检结果 ----------------
[完成] 内核进程：verge-mihomo 运行中（PID 1234）
[完成] 代理端口：127.0.0.1:7897 正在监听
[完成] 系统代理：已开启 -> 127.0.0.1:7897
-----------------------------------------
```

如果系统代理那行是 `[注意]`，去 Clash Verge 界面把「系统代理」开关打开就行。

### 第 3 步：导入你的订阅

Clash Verge → 「订阅」→ 新建 → 粘贴订阅链接 → 导入 → 选中它。
（这一步和本修复包无关，用你自己的机场链接。）

然后随便打开个网站验证一下，能上就完事了。

## 它到底修了什么

Clash Verge 自带的内核 `verge-mihomo.exe` 是按**较新的 x86-64 指令集**编译的。
老 CPU / 虚拟机的 CPU 缺少 SSE4.2、POPCNT、AVX 这类指令，内核一启动就触发
非法指令 / 访问违例，直接崩溃，连版本号都打不出来：

```powershell
& "C:\Program Files\Clash Verge\verge-mihomo.exe" -v
# 没有任何输出，退出码 -1073741819 (0xC0000005)
# 事件日志：Application Error 1000 / BEX64 / 0xc0000005
```

而 mihomo 官方提供了 **amd64-compatible** 构建，按 x86-64 基线指令集编译，
在老 CPU 上能正常跑。本修复包就是把这个内核换进去。

替换前原文件会备份为 `verge-mihomo.exe.orig-broken`，随时可以还原。

## 高级用法

```powershell
# 指定安装目录（Clash Verge 不在默认位置时）
.\fix-core.ps1 -ClashVergeDir "D:\Apps\Clash Verge"

# 指定别的内核文件（需要联网时也可以换版本）
.\fix-core.ps1 -SourceFile "D:\downloads\mihomo-windows-amd64-compatible.exe"
```

日志在 `C:\ProgramData\ClashVergeOldCpuFix\fix.log`，出问题先看它。

## 常见问题

**Q：跑完还是没网？**
先看体检结果：内核进程和 7897 端口都 `[完成]`、但系统代理 `[注意]`，
就去界面开系统代理。三行都 `[完成]` 还没网，多半是订阅本身过期/流量用完，
或者节点全挂，在 Clash Verge 里点「测速」看看。

**Q：以后升级 Clash Verge 又坏了？**
安装包会把内核覆盖回不兼容的版本。升级完重新双击一次 `fix.bat` 就行。
建议在「设置 → 常规」里关掉自动更新，免得某次更新后突然不能用。

**Q：杀毒软件报毒？**
脚本会往 `Program Files` 写文件、会调用 `curl` 下载，被拦是正常的。
把 `C:\Program Files\Clash Verge` 和这个文件夹加入信任即可。

**Q：TUN 模式能用吗？**
不建议。VDI / 虚拟机上 TUN 虚拟网卡经常和宿主网卡冲突，用系统代理模式就够。

## 想发到 GitHub

- 本仓库默认用 `.gitignore` 忽略了 `*.exe`，**不要**把 58MB 的内核提交进 git
- 需要别人离线使用时，把 `mihomo-windows-amd64-compatible.exe` 传到 **Releases** 附件
  （网页上传单文件上限 25MB，走 Releases 没这个问题）
- 仓库里绝对不要放订阅链接——里面带你的个人 token

## 已验证环境

| 项目 | 值 |
| --- | --- |
| 系统 | Windows 10 专业版 19045 |
| 环境 | 深信服 VDI（QEMU/KVM，模拟 Intel Core 2 Duo T7700） |
| Clash Verge | 2.5.8 / 2.5.10 |
| 内核 | mihomo v1.19.34 `windows-amd64-compatible`（go1.26.11） |
| 结果 | Google 204、GitHub 200、YouTube 200，系统代理正常 |

## 许可

脚本部分 MIT。内核二进制版权归 [MetaCubeX/mihomo](https://github.com/MetaCubeX/mihomo) 所有，遵循 GPL-3.0。

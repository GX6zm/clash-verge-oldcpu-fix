@echo off
cd /d "%~dp0"
echo ============================================
echo  Restore original Clash Verge core
echo ============================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore-core.ps1"
echo.
pause


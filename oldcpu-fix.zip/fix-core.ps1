﻿#requires -Version 5.1
<#
.SYNOPSIS
    一键把 Clash Verge 的内核换成「老 CPU 兼容版」，修复内核一启动就崩溃（0xC0000005）的问题。

.DESCRIPTION
    Clash Verge 自带的 verge-mihomo.exe 是按较新的 x86-64 指令集编译的。
    在缺少 SSE4.2 / POPCNT / AVX 等指令的 CPU（老笔记本、QEMU/KVM 虚拟机、
    深信服/华为云桌面等 VDI）上，内核一启动就崩溃，表现为：

        - 界面能打开，但内核一直「未运行」
        - 没有任何端口监听（7897 等）
        - 系统代理开不了、开了也没网
        - 事件日志：Application Error 1000，异常代码 0xc0000005，BEX64

    本脚本优先使用同目录下的 mihomo-windows-amd64-compatible*.exe（离线包自带），
    没有的话才去 GitHub / 镜像下载。替换前会备份原内核，替换后实际执行一次
    `-v` 校验，失败自动回滚；成功则启动 Clash Verge 并检查端口与系统代理状态。

.PARAMETER ClashVergeDir
    Clash Verge 安装目录，默认 C:\Program Files\Clash Verge

.PARAMETER CoreVersion
    需要联网下载时使用的 mihomo 版本，默认 v1.19.34

.PARAMETER SourceFile
    指定本地内核文件（.exe 或 .zip），优先级高于同目录自带文件和联网下载。

.EXAMPLE
    .\fix-core.ps1

.EXAMPLE
    .\fix-core.ps1 -ClashVergeDir "D:\Apps\Clash Verge"
#>
[CmdletBinding()]
param(
    [string]$ClashVergeDir = 'C:\Program Files\Clash Verge',
    [string]$CoreVersion = 'v1.19.34',
    [string]$SourceFile = ''
)

$ErrorActionPreference = 'Stop'

$WorkDir = Join-Path $env:ProgramData 'ClashVergeOldCpuFix'
$LogFile = Join-Path $WorkDir 'fix.log'
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null

function Write-Step {
    param([string]$Message)
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Host $Message
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# 把 Clash Verge 自己的「系统代理」开关预置为开启（Verge 退出时会把该值写成 false）
function Set-VergeProxyFlag {
    param([string]$Value = 'true')
    $v = Join-Path $env:APPDATA 'io.github.clash-verge-rev.clash-verge-rev\verge.yaml'
    if (-not (Test-Path $v)) { return $false }
    $text = [IO.File]::ReadAllText($v, [Text.Encoding]::UTF8)
    if ($text -notmatch '(?m)^enable_system_proxy:') { return $false }
    $new = [regex]::Replace($text, '(?m)^enable_system_proxy:.*$', "enable_system_proxy: $Value")
    [IO.File]::WriteAllText($v, $new, (New-Object Text.UTF8Encoding($false)))
    return $true
}

# 直接写 WinINET 设置兜底（Verge 没来得及开的情况下也能用）
function Enable-SystemProxy {
    param([string]$Server = '127.0.0.1:7897')
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    Set-ItemProperty -Path $key -Name ProxyServer -Value $Server
    Set-ItemProperty -Path $key -Name ProxyEnable -Value 1 -Type DWord
    Set-ItemProperty -Path $key -Name ProxyOverride -Value ('localhost;127.*;10.*;172.16.*;172.17.*;172.18.*;172.19.*;' +
        '172.20.*;172.21.*;172.22.*;172.23.*;172.24.*;172.25.*;172.26.*;172.27.*;172.28.*;' +
        '172.29.*;172.30.*;172.31.*;192.168.*;<local>')
    if (-not ('Win32.WinInet' -as [type])) {
        Add-Type -Namespace Win32 -Name WinInet -MemberDefinition @'
[DllImport("wininet.dll", SetLastError = true, CharSet = CharSet.Auto)]
public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);
'@
    }
    [void][Win32.WinInet]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0)
    [void][Win32.WinInet]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0)
}

# ---------- 1. 自动提权 ----------
if (-not (Test-Admin)) {
    Write-Host '需要管理员权限，正在请求提权（会弹出 UAC 提示，请点「是」）...'
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($ClashVergeDir -ne 'C:\Program Files\Clash Verge') { $argList += @('-ClashVergeDir', "`"$ClashVergeDir`"") }
    if ($CoreVersion -ne 'v1.19.34') { $argList += @('-CoreVersion', $CoreVersion) }
    if ($SourceFile) { $argList += @('-SourceFile', "`"$SourceFile`"") }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs
    return
}

Write-Step '================ 开始修复 Clash Verge 内核 ================'

$exe = Join-Path $ClashVergeDir 'clash-verge.exe'
$dst = Join-Path $ClashVergeDir 'verge-mihomo.exe'
$bak = Join-Path $ClashVergeDir 'verge-mihomo.exe.orig-broken'
$work = Join-Path $WorkDir 'download'

try {
    if (-not (Test-Path $ClashVergeDir)) { throw "找不到 Clash Verge 安装目录：$ClashVergeDir" }
    if (-not (Test-Path $dst)) { throw "找不到内核文件：$dst —— 请确认 Clash Verge 是否正确安装" }

    # ---------- 2. 准备新内核：本地优先 ----------
    $newCore = $null

    if ($SourceFile) {
        if (-not (Test-Path $SourceFile)) { throw "指定的本地文件不存在：$SourceFile" }
        if ([IO.Path]::GetExtension($SourceFile) -eq '.zip') {
            $ext = Join-Path $work 'local'
            Remove-Item $ext -Recurse -Force -ErrorAction SilentlyContinue
            Expand-Archive -Path $SourceFile -DestinationPath $ext -Force
            $newCore = (Get-ChildItem $ext -Filter '*.exe' -Recurse | Select-Object -First 1).FullName
        } else {
            $newCore = (Resolve-Path $SourceFile).Path
        }
        Write-Step "使用 -SourceFile 指定的内核：$newCore"
    }

    if (-not $newCore) {
        $localExe = Get-ChildItem $PSScriptRoot -Filter 'mihomo-windows-amd64-compatible*.exe' -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($localExe) {
            $newCore = $localExe.FullName
            Write-Step "使用文件夹内自带的内核：$($localExe.Name)（无需联网）"
        }
    }

    if (-not $newCore) {
        $zipName = "mihomo-windows-amd64-compatible-$CoreVersion.zip"
        $rel = "/MetaCubeX/mihomo/releases/download/$CoreVersion/$zipName"
        $mirrors = @(
            "https://ghfast.top/https://github.com$rel",
            "https://ghproxy.net/https://github.com$rel",
            "https://github.com$rel"
        )
        New-Item -ItemType Directory -Force -Path $work | Out-Null
        $zipPath = Join-Path $work $zipName
        $ok = $false
        foreach ($url in $mirrors) {
            Write-Step "文件夹内没有内核，尝试下载：$url"
            try {
                if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
                & curl.exe -L --fail --retry 1 --connect-timeout 10 --max-time 300 `
                    --speed-limit 1024 --speed-time 30 -o $zipPath $url 2>$null
                if ($LASTEXITCODE -eq 0 -and (Get-Item $zipPath).Length -gt 1MB) { $ok = $true; break }
                Write-Step "  该源不可用，换下一个"
            } catch {
                Write-Step "  该源不可用：$($_.Exception.Message)"
            }
        }
        if (-not $ok) { throw '所有下载源都失败。请把 mihomo-windows-amd64-compatible.exe 放到本文件夹里再重试。' }

        $ext = Join-Path $work 'extract'
        Remove-Item $ext -Recurse -Force -ErrorAction SilentlyContinue
        Expand-Archive -Path $zipPath -DestinationPath $ext -Force
        $newCore = (Get-ChildItem $ext -Filter '*.exe' -Recurse | Select-Object -First 1).FullName
        if (-not $newCore) { throw '下载的压缩包里没有找到 .exe 文件' }
    }

    # ---------- 3. 关闭 Clash Verge ----------
    if (Get-Process -Name 'clash-verge' -ErrorAction SilentlyContinue) {
        Write-Step '关闭 Clash Verge ...'
        Get-Process -Name 'clash-verge' -ErrorAction SilentlyContinue | Stop-Process -Force
        Start-Sleep -Seconds 3
    }
    Get-Process -Name 'verge-mihomo' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 1

    # Verge 退出时会把「系统代理」写成关闭，这里先预置成开启，它启动后会自动应用
    try {
        if (Set-VergeProxyFlag 'true') { Write-Step '已预置「系统代理」开关为开启' }
    } catch {
        Write-Step "预置系统代理开关失败（不影响内核修复）：$($_.Exception.Message)"
    }

    # ---------- 4. 备份 + 替换 ----------
    if (-not (Test-Path $bak)) {
        Copy-Item $dst $bak -Force
        Write-Step "已备份原内核：$bak"
    } else {
        Write-Step '原内核备份已存在，保留不覆盖'
    }

    Copy-Item $newCore $dst -Force
    $h1 = (Get-FileHash $newCore -Algorithm SHA256).Hash
    $h2 = (Get-FileHash $dst -Algorithm SHA256).Hash
    if ($h1 -ne $h2) { throw '复制后校验不一致，文件可能被杀毒软件拦截' }
    Write-Step "内核已替换，SHA256=$h2"

    # ---------- 5. 实际运行校验 ----------
    Write-Step '校验新内核能否运行 ...'
    $out = & $dst -v 2>&1 | Out-String
    $code = $LASTEXITCODE
    Write-Step ("  -v 输出：" + ($out.Trim() -replace "`r?`n", ' | '))
    if ($code -ne 0 -or $out -notmatch 'Mihomo') {
        Write-Step "新内核同样无法运行（退出码 $code），正在回滚 ..."
        Copy-Item $bak $dst -Force
        throw '新内核在本机无法运行，已恢复原文件。请换一个版本或换兼容构建重试。'
    }

    # ---------- 6. 启动并体检 ----------
    Write-Step '启动 Clash Verge ...'
    Start-Process $exe
    $proc = $null
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt 45) {
        $proc = Get-Process -Name 'verge-mihomo' -ErrorAction SilentlyContinue
        if ($proc) { break }
        Start-Sleep -Milliseconds 800
    }

    # 内核进程出现后，端口还要几秒才监听，最多等 30 秒
    $listen = $false
    $sw2 = [Diagnostics.Stopwatch]::StartNew()
    while ($sw2.Elapsed.TotalSeconds -lt 30) {
        try {
            $listen = [bool](Get-NetTCPConnection -State Listen -LocalPort 7897 -ErrorAction SilentlyContinue)
        } catch { }
        if ($listen) { break }
        Start-Sleep -Milliseconds 1000
    }

    # 再等 Verge 自己开系统代理（最多 20 秒），没开就兜底写注册表
    $proxyKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    $ie = Get-ItemProperty $proxyKey -ErrorAction SilentlyContinue
    $sw3 = [Diagnostics.Stopwatch]::StartNew()
    while ($sw3.Elapsed.TotalSeconds -lt 20 -and $ie.ProxyEnable -ne 1) {
        Start-Sleep -Milliseconds 800
        $ie = Get-ItemProperty $proxyKey -ErrorAction SilentlyContinue
    }
    if ($ie.ProxyEnable -ne 1) {
        Write-Step 'Verge 没有自动开启系统代理，脚本兜底开启 ...'
        try {
            Enable-SystemProxy
            $ie = Get-ItemProperty $proxyKey -ErrorAction SilentlyContinue
        } catch {
            Write-Step "兜底开启系统代理失败：$($_.Exception.Message)"
        }
    }

    $proc = Get-Process -Name 'verge-mihomo' -ErrorAction SilentlyContinue
    $sysProxy = ($ie.ProxyEnable -eq 1)

    Write-Step ''
    Write-Step '---------------- 体检结果 ----------------'
    if ($proc) { Write-Step ("[完成] 内核进程：verge-mihomo 运行中（PID {0}）" -f $proc.Id) }
    else { Write-Step '[注意] 内核进程没有出现，请打开 Clash Verge 看界面报错' }
    if ($listen) { Write-Step '[完成] 代理端口：127.0.0.1:7897 正在监听' }
    else { Write-Step '[注意] 7897 端口未监听' }
    if ($sysProxy) { Write-Step ("[完成] 系统代理：已开启 -> {0}" -f $ie.ProxyServer) }
    else { Write-Step '[注意] 系统代理未开启，请到 Clash Verge 界面打开「系统代理」开关' }
    Write-Step '-----------------------------------------'
    Write-Step ''

    if ($proc -and $listen) {
        Write-Step '================ 修复完成 ================'
        Set-Content -Path (Join-Path $WorkDir 'ok.txt') -Value 'ok' -Encoding UTF8
        exit 0
    }

    Write-Step '================ 修复未完全成功 ================'
    exit 1
}
catch {
    Write-Step "失败：$($_.Exception.Message)"
    Set-Content -Path (Join-Path $WorkDir 'err.txt') -Value $_.Exception.Message -Encoding UTF8
    exit 1
}
